<?php
	$user = "scott";
	$pass = "tiger";
	$db = "xe";
?>